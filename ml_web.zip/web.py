from flask import Flask, render_template, request
import neuro

app = Flask(__name__)


@app.route('/', methods=['POST', 'GET'])
def home():
    if request.method == 'POST':
        data = request.form.get('input1')
        print(data)
    return render_template('home.html')