def neuro(**args):
    pass